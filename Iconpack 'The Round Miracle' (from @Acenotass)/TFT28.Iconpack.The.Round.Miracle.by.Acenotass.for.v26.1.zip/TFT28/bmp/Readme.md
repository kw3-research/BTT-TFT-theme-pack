The iconpack "The Round Miracle" was made by Sergey Alexeyev (Acenotass). GIMP and Paint.NET graphic editors were used to create the icons.
Use only for firmware version above 25.3
email: s.n.alexeyev@gmail.com
